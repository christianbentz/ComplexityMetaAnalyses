
Morphological Complexity
========================

To calculate morphological complexity (MC), you can run an R script "morphologicalComplexity.R" found in the following directory ("morphological complexity"). You will need to set up this directory as your working directory in R in order to run this R script.


Information Density
===================

0. In the directory ("information density/Texts_FullParallel"), you can first clean the data (I've used the parallel version) by using the following command line in the terminal: $ bash cleaning.sh
(The clean version of data is included in the directory, so you can skip this step!)

1. In the directory ("information density"), you will find an R script "informationDensity.R" to calculate word information density (WID) and syllable information density (SID).

2. It is described in the script but just for info, the working directory for calculating WID is ("information density/Texts_FullParallel") and for SID is ("information density/Texts_Syllabified").

3. In the directory ("information density/Texts_Syllabified"), a text file ("Syllabification.txt") describes how the data were syllabified (it was possible only for 10 languages).





