# Calculating Morphological Complexity (O_MC)
library(readr);library(ggplot2)
# setwd("/submission/code/morphological complexity")

# Loading a language list
languageList <- read_csv("./languageList.txt", col_names = FALSE)
colnames(languageList)[1] <- "Language"

# Loading values for each parameter (30 in total) obtained from WALS
X20A <- read_delim("./20A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X20A$`20A`)
allList <- merge(X20A, languageList, by="Language", all="TRUE"); allList$S20A <- 0 
allList[!is.na(allList$`20A`) & allList$`20A`=="Exclusively isolating",]$S20A <- -1
allList[!is.na(allList$`20A`) & allList$`20A`=="Isolating/concatenative",]$S20A <- -0.5
allList[!is.na(allList$`20A`) & allList$`20A`=="Tonal/isolating",]$S20A <- -0.5

X26A <- read_delim("./26A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X26A$`26A`)
allList <- merge(X26A, allList, by="Language", all="TRUE"); allList$S26A <- 0
allList[!is.na(allList$`26A`) & allList$`26A`=="Little affixation",]$S26A <- -1

X49A <- read_delim("./49A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X49A$`49A`)
allList <- merge(X49A, allList, by="Language", all="TRUE"); allList$S49A <- 0
allList[!is.na(allList$`49A`) & allList$`49A`=="No morphological case-marking",]$S49A <- -1
allList[!is.na(allList$`49A`) & allList$`49A`=="Exclusively borderline case-marking",]$S49A <- -1
allList[!is.na(allList$`49A`) & allList$`49A`=="2 cases",]$S49A <- -0.8
allList[!is.na(allList$`49A`) & allList$`49A`=="3 cases",]$S49A <- -0.7
allList[!is.na(allList$`49A`) & allList$`49A`=="4 cases",]$S49A <- -0.6
allList[!is.na(allList$`49A`) & allList$`49A`=="5 cases",]$S49A <- -0.5
allList[!is.na(allList$`49A`) & allList$`49A`=="6-7 cases",]$S49A <- -0.35
allList[!is.na(allList$`49A`) & allList$`49A`=="8-9 cases",]$S49A <- -0.15

X28A <- read_delim("./28A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X28A$`28A`)
allList <- merge(X28A, allList, by="Language", all="TRUE"); allList$S28A <- 0
allList[!is.na(allList$`28A`) & allList$`28A`=="No case marking",]$S28A <- -1
allList[!is.na(allList$`28A`) & allList$`28A`=="No syncretism",]$S28A <- -1
allList[!is.na(allList$`28A`) & allList$`28A`=="Core cases only",]$S28A <- -0.5

X98A <- read_delim("./98A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X98A$`98A`)
allList <- merge(X98A, allList, by="Language", all="TRUE"); allList$S98A <- 0
allList[!is.na(allList$`98A`) & allList$`98A`=="Neutral",]$S98A <- -1

X22A <- read_delim("./22A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X22A$`22A`)
allList <- merge(X22A, allList, by="Language", all="TRUE"); allList$S22A <- 0
allList[!is.na(allList$`22A`) & allList$`22A`=="8-9 categories per word",]$S22A <- -0.15
allList[!is.na(allList$`22A`) & allList$`22A`=="6-7 categories per word",]$S22A <- -0.35
allList[!is.na(allList$`22A`) & allList$`22A`=="4-5 categories per word",]$S22A <- -0.55
allList[!is.na(allList$`22A`) & allList$`22A`=="2-3 categories per word",]$S22A <- -0.75
allList[!is.na(allList$`22A`) & allList$`22A`=="0-1 category per word",]$S22A <- -0.95

X100A <- read_delim("./100A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X100A$`100A`)
allList <- merge(X100A, allList, by="Language", all="TRUE"); allList$S100A <- 0
allList[!is.na(allList$`100A`) & allList$`100A`=="Neutral",]$S100A <- -1

X102A <- read_delim("./102A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X102A$`102A`)
allList <- merge(X102A, allList, by="Language", all="TRUE"); allList$S102A <- 0
allList[!is.na(allList$`102A`) & allList$`102A`=="No person marking",]$S102A <- -1
allList[!is.na(allList$`102A`) & allList$`102A`=="Only the A argument",]$S102A <- -0.5
allList[!is.na(allList$`102A`) & allList$`102A`=="Only the P argument",]$S102A <- -0.5
allList[!is.na(allList$`102A`) & allList$`102A`=="A or P argument",]$S102A <- -0.5

X48A <- read_delim("./48A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X48A$`48A`)
allList <- merge(X48A, allList, by="Language", all="TRUE"); allList$S48A <- 0
allList[!is.na(allList$`48A`) & allList$`48A`=="No person marking",]$S48A <- -1
allList[!is.na(allList$`48A`) & allList$`48A`=="No adpositions",]$S48A <- -1
allList[!is.na(allList$`48A`) & allList$`48A`=="Pronouns only",]$S48A <- -0.5

X29A <- read_delim("./29A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X29A$`29A`)
allList <- merge(X29A, allList, by="Language", all="TRUE"); allList$S29A <- 0
allList[!is.na(allList$`29A`) & allList$`29A`=="No subject person/number marking",]$S29A <- -1
allList[!is.na(allList$`29A`) & allList$`29A`=="Not syncretic",]$S29A <- -1

X74A <- read_delim("./74A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X74A$`74A`)
allList <- merge(X74A, allList, by="Language", all="TRUE"); allList$S74A <- 0
allList[!is.na(allList$`74A`) & allList$`74A`=="Verbal constructions",]$S74A <- -1
allList[!is.na(allList$`74A`) & allList$`74A`=="Other kinds of markers",]$S74A <- -1

X75A <- read_delim("./75A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X75A$`75A`)
allList <- merge(X75A, allList, by="Language", all="TRUE"); allList$S75A <- 0
allList[!is.na(allList$`75A`) & allList$`75A`=="Verbal constructions",]$S75A <- -1
allList[!is.na(allList$`75A`) & allList$`75A`=="Other",]$S75A <- -1

X76A <- read_delim("./76A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X76A$`76A`)
allList <- merge(X76A, allList, by="Language", all="TRUE"); allList$S76A <- 0
allList[!is.na(allList$`76A`) & allList$`76A`=="Overlap for either possibility or necessity",]$S76A <- -0.5
allList[!is.na(allList$`76A`) & allList$`76A`=="No overlap",]$S76A <- -1

X77A <- read_delim("./77A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X77A$`77A`)
allList <- merge(X77A, allList, by="Language", all="TRUE"); allList$S77A <- 0
allList[!is.na(allList$`77A`) & allList$`77A`=="No grammatical evidentials",]$S77A <- -1
allList[!is.na(allList$`77A`) & allList$`77A`=="Indirect only",]$S77A <- -0.5

X112A <- read_delim("./112A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X112A$`112A`)
allList <- merge(X112A, allList, by="Language", all="TRUE"); allList$S112A <- 0
allList[!is.na(allList$`112A`) & allList$`112A`=="Negative particle",]$S112A <- -1
allList[!is.na(allList$`112A`) & allList$`112A`=="Negative auxiliary verb",]$S112A <- -1
allList[!is.na(allList$`112A`) & allList$`112A`=="Negative word, unclear if verb or particle",]$S112A <- -1
allList[!is.na(allList$`112A`) & allList$`112A`=="Variation between negative word and affix",]$S112A <- -0.5
                              
X34A <- read_delim("./34A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X34A$`34A`)
allList <- merge(X34A, allList, by="Language", all="TRUE"); allList$S34A <- 0
allList[!is.na(allList$`34A`) & allList$`34A`=="No nominal plural",]$S34A <- -1
allList[!is.na(allList$`34A`) & allList$`34A`=="All nouns, always optional",]$S34A <- -0.5
allList[!is.na(allList$`34A`) & allList$`34A`=="Only human nouns, optional",]$S34A <- -0.5
allList[!is.na(allList$`34A`) & allList$`34A`=="All nouns, optional in inanimates",]$S34A <- -0.5

X36A <- read_delim("./36A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X36A$`36A`)
allList <- merge(X36A, allList, by="Language", all="TRUE"); allList$S36A <- 0
allList[!is.na(allList$`36A`) & allList$`36A`=="No associative plural",]$S36A <- -1

X92A <- read_delim("./92A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X92A$`92A`)
allList <- merge(X92A, allList, by="Language", all="TRUE"); allList$S92A <- 0
allList[!is.na(allList$`92A`) & allList$`92A`=="No question particle",]$S92A <- -1

X67A <- read_delim("./67A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X67A$`67A`)
allList <- merge(X67A, allList, by="Language", all="TRUE"); allList$S67A <- 0
allList[!is.na(allList$`67A`) & allList$`67A`=="No inflectional future",]$S67A <- -1

X66A <- read_delim("./66A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X66A$`66A`)
allList <- merge(X66A, allList, by="Language", all="TRUE"); allList$S66A <- 0
allList[!is.na(allList$`66A`) & allList$`66A`=="No past tense",]$S66A <- -1

X65A <- read_delim("./65A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X65A$`65A`)
allList <- merge(X65A, allList, by="Language", all="TRUE"); allList$S65A <- 0
allList[!is.na(allList$`65A`) & allList$`65A`=="No grammatical marking",]$S65A <- -1

X70A <- read_delim("./70A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X70A$`70A`)
allList <- merge(X70A, allList, by="Language", all="TRUE"); allList$S70A <- 0
allList[!is.na(allList$`70A`) & allList$`70A`=="No second-person imperatives",]$S70A <- -1

X57A <- read_delim("./57A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X57A$`57A`)
allList <- merge(X57A, allList, by="Language", all="TRUE"); allList$S57A <- 0
allList[!is.na(allList$`57A`) & allList$`57A`=="No possessive affixes",]$S57A <- -1

X59A <- read_delim("./59A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X59A$`59A`)
allList <- merge(X59A, allList, by="Language", all="TRUE"); allList$S59A <- 0
allList[!is.na(allList$`59A`) & allList$`59A`=="No possessive classification",]$S59A <- -1

X73A <- read_delim("./73A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X73A$`73A`)
allList <- merge(X73A, allList, by="Language", all="TRUE"); allList$S73A <- 0
allList[!is.na(allList$`73A`) & allList$`73A`=="Inflectional optative absent",]$S73A <- -1

X37A <- read_delim("./37A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X37A$`37A`)
allList <- merge(X37A, allList, by="Language", all="TRUE"); allList$S37A <- 0
allList[!is.na(allList$`37A`) & allList$`37A`=="No definite or indefinite article",]$S37A <- -1
allList[!is.na(allList$`37A`) & allList$`37A`=="No definite, but indefinite article",]$S37A <- -1

X38A <- read_delim("./38A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X38A$`38A`)
allList <- merge(X38A, allList, by="Language", all="TRUE"); allList$S38A <- 0
allList[!is.na(allList$`38A`) & allList$`38A`=="No definite or indefinite article",]$S38A <- -1
allList[!is.na(allList$`38A`) & allList$`38A`=="No indefinite, but definite article",]$S38A <- -1

X41A <- read_delim("./41A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X41A$`41A`)
allList <- merge(X41A, allList, by="Language", all="TRUE"); allList$S41A <- 0
allList[!is.na(allList$`41A`) & allList$`41A`=="No distance contrast",]$S41A <- -1

X101A <- read_delim("./101A.txt", "\t", escape_double = FALSE, trim_ws = TRUE); unique(X101A$`101A`)
allList <- merge(X101A, allList, by="Language", all="TRUE"); allList$S101A <- 0
allList[!is.na(allList$`101A`) & allList$`101A`=="Subject pronouns in different position",]$S101A <- -1
allList[!is.na(allList$`101A`) & allList$`101A`=="Obligatory pronouns in subject position",]$S101A <- -1
allList[!is.na(allList$`101A`) & allList$`101A`=="Mixed",]$S101A <- -1
allList[!is.na(allList$`101A`) & allList$`101A`=="Subject clitics on variable host",]$S101A <- -1
allList[!is.na(allList$`101A`) & allList$`101A`=="Optional pronouns in subject position",]$S101A <- -1

# Summing all values to obtain morphological complexity 
allList$sum <- apply(allList[,c("S20A","S26A","S49A","S28A","S98A","S22A","S100A","S102A","S48A","S29A","S74A","S75A",
               "S76A","S77A","S112A","S34A","S36A","S92A","S67A","S66A","S65A","S70A","S57A","S59A","S73A","S37A",
               "S38A","S41A","S101A")],1,sum)

# Getting the number of NAs for each language and normalizing the sum by the number of available features
allListFeatures <- allList[,c("Language","20A","26A","49A","28A","98A","22A","100A","102A","48A","29A","74A","75A",
                  "76A","77A","112A","34A","36A","92A","67A","66A","65A","70A","57A","59A","73A","37A","38A","41A",
                  "101A")]
allListFeatures$sumNA <- apply(is.na(allListFeatures),1,sum)
allListFeatures$totalF <- 29 - allListFeatures$sumNA
allListFeatures <- allListFeatures[,c("Language","totalF")]
allList <- merge(allList, allListFeatures, by="Language")
allList$MC <- allList$sum/allList$totalF

# Getting the score of languages listed in the task
listFinal <- allList[allList$Language %in% languageList$Language,]
listFinal <- listFinal[order(listFinal$MC),];listFinal$id <- seq_along(listFinal$Language)
ggplot(listFinal, aes(x=id,y=MC)) + geom_point(size=0.5) + theme_classic() +
  geom_text(aes(x=id,y=MC,label=Language), vjust=-0.5,size=3) +
  labs(x="Language ID",y="Morphological complexity") 

# Saving the results
listFinal <- listFinal[,c("Language","MC")]
write.table(listFinal, "MC.txt", quote=FALSE, col.name=TRUE, row.names=FALSE)
