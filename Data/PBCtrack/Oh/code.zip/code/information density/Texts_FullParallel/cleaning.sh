#!/bin/bash
for filename in *.txt; do cat "$filename" | grep -v "^#" | cut -f2 | sed 's/[-―—«»:;‘’।॥!¡()¿?"“”,`\.]//g' | sed "s/\'//g" | sed 's/[][]//g' | sed 's/   / /g' | sed 's/  / /g' | sed 's/^ //g' | sed 's/ $//g' >  "clean_${filename}"; done

#comment
echo finished!
