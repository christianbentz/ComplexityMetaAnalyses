# 1. Calculating Word Information Density (WID)
library(readr)
# setwd("~/submission/code/information density/Texts_FullParallel")

# Counting the number of words in each line for Thai (language with the lowest morphological complexity among the language sample)
clean_tha_x_bible_standard2011 <- read_delim("./clean_tha-x-bible-standard2011.txt", "\t", escape_double = FALSE, col_names = FALSE, 
trim_ws = TRUE)
wordCount <- as.data.frame(sapply(strsplit(clean_tha_x_bible_standard2011$X1, " "), length))
colnames(wordCount)[1] <- "tha"
wordCount$id <- seq_along(wordCount$tha)

# Loading the list of file names and language codes
list <- read_delim("./list.txt","\t", escape_double = FALSE, trim_ws = TRUE)

# Function to calculate Word Information Density (WID), using Thai as a reference
wordCountCal <- function(bible, languageCode){
  bible <- read_delim(bible,"\t", escape_double = FALSE, col_names = FALSE, trim_ws = TRUE)
  bible <- as.data.frame(sapply(strsplit(bible$X1, " "), length))
  colnames(bible)[1] <- languageCode
  bible$id <- seq_along(bible[,1])
  wordCount <- merge(wordCount,bible, by="id")
  wordCount$WID <- wordCount$tha/wordCount[,ncol(wordCount)]
  wid <- sum(wordCount$WID)/nrow(wordCount)
  langWid <- c(languageCode, wid)
  return(langWid)
}

# Calculating the WID using the list of file names and language codess
widList <- list()
widLanList <- list()
for(i in 1:nrow(list)){
bible <- list$bible[i]
languageCode <- list$languageCode[i]
widList[[i]] <- wordCountCal(bible,languageCode)[2]
widLanList[[i]] <- wordCountCal(bible,languageCode)[1]
}
widLists <- as.data.frame(cbind(unlist(widLanList),unlist(widList)))
colnames(widLists) <- c("language","wid")
widLists <- widLists[order(widLists$wid, decreasing=TRUE),]

# Saving the results
write.table(widLists, "WID.txt", quote=FALSE, col.name=TRUE, row.names=FALSE)

# 2. Calculating Syllable Information Density (SID)
# setwd("~/submission/code/information density/Texts_Syllabified")

# Counting the number of syllables in each line for Korean (language with the lowest morphological complexity among those with syllabified data)
korSyl <- read_delim("./korSyl.txt", "\t", escape_double = FALSE, col_names = FALSE, trim_ws = TRUE)
sylCount <- as.data.frame(sapply(strsplit(korSyl$X1, " "), length))
colnames(sylCount)[1] <- "kor";sylCount$id <- seq_along(sylCount$kor)

# Loading the list of file names and language codes
listSyl <- read_delim("./listSyl.txt","\t", escape_double = FALSE, trim_ws = TRUE)

# Function to calculate Syllable Information Density (SID), using Korean as a reference
sylCountCal <- function(sylText, languageCode){
  sylText <- read_delim(sylText,"\t", escape_double = FALSE, col_names = FALSE, trim_ws = TRUE)
  sylText <- as.data.frame(sapply(strsplit(sylText$X1, " "), length))
  colnames(sylText)[1] <- languageCode
  sylText$id <- seq_along(sylText[,1])
  sylCount <- merge(sylCount,sylText, by="id")
  sylCount$SID <- sylCount$kor/sylCount[,ncol(sylCount)]
  sid <- sum(sylCount$SID)/nrow(sylCount)
  langSid <- c(languageCode, sid)
  return(langSid)
}

# Calculating the SID using the list of file names and language codes
sidList <- list()
sidLanList <- list()
for(i in 1:nrow(listSyl)){
  sylText <- listSyl$sylText[i]
  languageCode <- listSyl$languageCode[i]
  sidList[[i]] <- sylCountCal(sylText,languageCode)[2]
  sidLanList[[i]] <- sylCountCal(sylText,languageCode)[1]
}
sidLists <- as.data.frame(cbind(unlist(sidLanList),unlist(sidList)))
colnames(sidLists) <- c("language","sid")
sidLists <- sidLists[order(sidLists$sid, decreasing=TRUE),]

# Saving the results
write.table(sidLists, "SID.txt", quote=FALSE, col.name=TRUE, row.names=FALSE)
